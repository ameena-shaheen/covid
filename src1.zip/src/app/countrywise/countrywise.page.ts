import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RestapiService } from './../restapi.service'



@Component({
  selector: 'app-countrywise',
  templateUrl: './countrywise.page.html',
  styleUrls: ['./countrywise.page.scss'],
})
export class countrywise {
  private data;
  public country:any;
  public activeCases:any;
  public totalCases;

  constructor(public route:Router,private actRoute:ActivatedRoute, public restapi: RestapiService) {
    this.actRoute.queryParams.subscribe(params => {
        console.log(params);
        this.country = params['country'];
        console.log(this.country)
        console.log("Before callin rest service "+this.country);
     this.restapi.getCountrywise(this.country).subscribe((response) => {
      console.log(response);
      this.activeCases = response['Active Cases_text'];
      this.totalCases = response['Total Cases_text'];
      this.country = response['Country_text'];
      this.data = response;
      })
    });
    
     
  }
  
}
